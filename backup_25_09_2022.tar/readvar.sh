#!/usr/bin/bash
read var1
echo  "var1: $var1"
read -p "enter  a value :" var2 
echo "var2: $var2"
read -sp "enter the value : " var3
# echo ""
echo "var3: $var3" 