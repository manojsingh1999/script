#!/bin/bash

# echo "hello $(whoami)! i am your assistant!"
# read -p "enter your name : " name
# echo "hello $name" 

var1="variable1";
echo $var1;

var1="variable 1 is upadted"
echo $var1

readonly var2="readonly variable"
echo $var2

var2="can i change var 2?"
echo $var2