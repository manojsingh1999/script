a=1
b=3

if [ $a -eq $b ];
then
    echo "yes a and b are equal"
else
    echo "not the same"
fi