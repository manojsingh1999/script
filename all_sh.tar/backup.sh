#!/bin/bash

f1="home/manoj/Documents/Commands/script"

tar cvf commands.tar $f1
